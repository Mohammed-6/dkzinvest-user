import Onboard from "../src/client/landing/onboard";

export default function Home() {
  return <Onboard />;
}
