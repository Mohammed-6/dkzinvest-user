import Dashboard from "../../src/client/landing/invest-done";

export default function Home() {
  return <Dashboard />;
}
