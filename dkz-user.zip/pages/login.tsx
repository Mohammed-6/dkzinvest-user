import Login from "../src/client/login";

export default function Home() {
  return <Login />;
}
