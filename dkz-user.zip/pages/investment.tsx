import Dashboard from "../src/client/landing/investment";

export default function Home() {
  return <Dashboard />;
}
