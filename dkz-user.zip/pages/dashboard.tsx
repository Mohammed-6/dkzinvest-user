import Dashboard from "../src/client/landing/dashboard";

export default function Home() {
  return <Dashboard />;
}
