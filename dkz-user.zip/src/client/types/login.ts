

export type loginProps = {
    phone: number;
    rememberToken: string;
}